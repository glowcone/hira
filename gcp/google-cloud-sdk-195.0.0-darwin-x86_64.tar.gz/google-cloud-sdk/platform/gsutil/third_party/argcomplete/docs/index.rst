.. include:: ../README.rst

API documentation
=================

.. autofunction:: argcomplete.autocomplete

.. automodule:: argcomplete
   :members:
   :special-members:
   :exclude-members: __weakref__

Table of Contents
=================

.. toctree::
   :maxdepth: 5

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
